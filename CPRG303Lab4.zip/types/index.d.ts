declare module "*.png";
declare module "*.jpg";